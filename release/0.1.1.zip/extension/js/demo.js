/**
 * User: mcxiaoke
 * Date: 13-7-13
 * Time: 上午11:09
 */
console.log("hello, js!");
